@include('layouts.header')

       <h3 style="text-align:center;font-weight: bold;"> No Products Fount</h3>


@include('layouts.footer')

</body>

</html>