<!DOCTYPE html>
<html>
<head>
    <title></title>
</head>
<body>
    <h3><a href="{{url('/customer/Reset-Passwordlink/'.$email)}}" method="get"><span>password reset link</span></a></h3>
    <p>Thank you</p>
</body>
</html>
